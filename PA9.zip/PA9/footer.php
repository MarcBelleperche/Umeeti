<!DOCTYPE html>
<html>
<footer>
	<label class="bottom">Designed for UMEETI CORP</label>
</footer>
</html>